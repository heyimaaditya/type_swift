-- AlterTable
ALTER TABLE "users" ALTER COLUMN "accountType" SET DEFAULT 'free';
